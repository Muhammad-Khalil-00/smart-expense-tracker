import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../models/user_model.dart';

class AuthProvider extends ChangeNotifier {
  final Box<UserModel> _userBox = Hive.box<UserModel>('users');
  final Box _sessionBox = Hive.box('session');

  UserModel? _currentUser;
  UserModel? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;

  /// Generates a random 16-byte salt, base64 encoded.
  String _generateSalt() {
    final rand = Random.secure();
    final bytes = List<int>.generate(16, (_) => rand.nextInt(256));
    return base64UrlEncode(bytes);
  }

  /// Hashes password + salt using SHA-256.
  String _hashPassword(String password, String salt) {
    final bytes = utf8.encode(password + salt);
    return sha256.convert(bytes).toString();
  }

  /// Restores session on app start (Persistent Session requirement)
  Future<bool> tryAutoLogin() async {
    final userId = _sessionBox.get('userId');
    if (userId == null) return false;

    try {
      final user = _userBox.values.firstWhere((u) => u.id == userId);
      _currentUser = user;
      notifyListeners();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<String?> register(String name, String email, String password) async {
    final emailLower = email.trim().toLowerCase();

    final exists =
        _userBox.values.any((u) => u.email.toLowerCase() == emailLower);
    if (exists) return 'An account with this email already exists.';

    final salt = _generateSalt();

    final user = UserModel(
      id: const Uuid().v4(),
      name: name.trim(),
      email: emailLower,
      passwordHash: _hashPassword(password, salt),
      createdAt: DateTime.now(),
      salt: salt,
    );

    await _userBox.add(user);
    _currentUser = user;
    await _sessionBox.put('userId', user.id);
    notifyListeners();
    return null; // null = success
  }

  Future<String?> login(String email, String password) async {
    final emailLower = email.trim().toLowerCase();

    UserModel? user;
    try {
      user = _userBox.values.firstWhere((u) => u.email.toLowerCase() == emailLower);
    } catch (_) {
      return 'Invalid email or password.';
    }

    final hashed = _hashPassword(password, user.salt);
    if (hashed != user.passwordHash) {
      return 'Invalid email or password.';
    }

    _currentUser = user;
    await _sessionBox.put('userId', user.id);
    notifyListeners();
    return null;
  }

  Future<void> logout() async {
    _currentUser = null;
    await _sessionBox.delete('userId');
    notifyListeners();
  }
}
